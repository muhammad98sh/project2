package com.company;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
	// write your code here
        Scanner scanobj=new Scanner(System.in);
        Customers customer=new Customers();
        Debtors debtor=new Debtors();
        String name;
        String email;
        String address;
        String product;
        int phone;
        int decide;
        double price;
        double price1 = 0;
        try {
            System.out.println("Write the name:-");
            name = scanobj.nextLine();
            customer.setName(name);
            System.out.println("Write the Email:-");
            email = scanobj.nextLine();
            customer.setEmail(email);
            System.out.println("Write the address:-");
            address = scanobj.nextLine();
            customer.setAddress(address);
            System.out.println("Write the Product:-");
            product = scanobj.nextLine();
            customer.setProduct(product);
            System.out.println("If he/she is not in the debtors list write 1");
            System.out.println("If he/she is in the debtors list write 2");
            decide=scanobj.nextInt();
            if (decide==1){
                System.out.println("Write the price:");
                price=scanobj.nextInt();
                price1=customer.more(price);
            }
            if (decide==2){
                System.out.println("Write the price:");
                price=scanobj.nextInt();
                price1=debtor.more(price);
            }
            System.out.println("Write the phone number:-");
            phone = scanobj.nextInt();
            customer.setPhone(phone);
        }catch (Exception e){
            System.out.println("\n");
            System.out.println("Wrong Input");
            System.out.println("\n");
        }
        System.out.println("To see the output by array write 1");
        System.out.println("To see the customer information write 2");
        System.out.println("To exit write 0");
        decide = scanobj.nextInt();
        if (decide==1) {
            Customers.customer1.add(customer);
            System.out.println(Customers.customer1.get(0).getName()+"\t"+Customers.customer1.get(0).getProduct()+"\t"+price1);
        }
        if (decide==2){
            System.out.println("Customer name is: "+customer.getName());
            System.out.println("Customer Email is: "+customer.getEmail());
            System.out.println("Customer address is: "+customer.getAddress());
            System.out.println("Customer Phone number is: "+customer.getPhone());
            System.out.println("Product is:"+customer.getProduct());
            System.out.println("Price is:"+price1);
        }
    }
}
