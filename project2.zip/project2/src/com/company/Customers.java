package com.company;

import java.util.ArrayList;

public class Customers {
    public String name;
    public String email;
    public int phone;
    public String address;
    public String product;
    //public int price;
    public double more(double price){
        if (price>100000){
            price=price*1.05;
        }
        return price;
    }

    public static ArrayList<Customers> customer1= new ArrayList<>();

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public int getPhone() {
        return phone;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getProduct() {
        return product;
    }

}