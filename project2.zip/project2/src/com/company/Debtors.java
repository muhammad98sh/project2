package com.company;

public class Debtors extends Customers {
    String date;
    @Override
    public double more(double price){
        if (price>5000){
            price=price*1.05;
        }
        return price;
    }
}
